---
layout:     post
title:      Hello, world !
subtitle:   第一篇博客
date:       2020.10.02
author:     追殇
header-img: 
catalog:   true
tags:
    - Hello, world!
---
# 建站引言

本博客建立于 `2020.10.2` ，基于 [Github](https://github.com/chen2438/chen2438.github.io) 搭建。

目前正在完善中

之前的文章为旧博客转载