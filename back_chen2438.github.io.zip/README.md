Welcome to 追殇's Blog！

本站建立于2020.10.2

现为 陈昊天 的个人博客

### 您可以 ——

1. 帮助美化、完善本网站。
2. [实验性]发表合适的博客（请在_posts目录下创建新的帖子，文件名和内容格式参考已有帖子）。

### 致谢

0. 这个模板最后是从 [Henri Jambo](https://github.com/globien/globien.github.io) fork 的，感谢作者。
1. 这个模板是从这里 [BY](https://github.com/qiubaiying/qiubaiying.github.io) fork 的, 感谢作者BY。 
2. BY的模板应该是从这个模板 [Hux](https://github.com/Huxpro/huxpro.github.io) fork 的, 也一起感谢一下。
3. 感谢 Jekyll、Github Pages 和 Bootstrap!

### License

MIT License, please refer to [LICENSE](https://github.com/chen2438/chen2438.github.io/blob/master/LICENSE).
